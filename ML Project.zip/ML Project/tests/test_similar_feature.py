import os
import sys
import unittest
import json

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import app
from database.models import db_session, User, Watchlist, init_db
from ml.recommendation import MovieRecommender

class TestSimilarMoviesFeature(unittest.TestCase):
    """
    Comprehensive Test Suite for CineMatch AI Similar Movies Feature
    Validates all 12 Phase 8 test requirements.
    """
    @classmethod
    def setUpClass(cls):
        init_db()
        cls.recommender = MovieRecommender.get_instance()

    def setUp(self):
        app.config['TESTING'] = True
        self.client = app.test_client()

        # Create authenticated test user
        db_session.query(Watchlist).delete()
        db_session.query(User).filter(User.email == 'similar_tester@example.com').delete()
        db_session.commit()

        self.user = User(full_name="Similar Tester", email="similar_tester@example.com")
        self.user.set_password("SecurePass123")
        db_session.add(self.user)
        db_session.commit()
        self.user_id = self.user.id

        with self.client.session_transaction() as sess:
            sess['user_id'] = self.user_id
            sess['user_name'] = "Similar Tester"
            sess['user_email'] = "similar_tester@example.com"

    def tearDown(self):
        db_session.query(Watchlist).delete()
        db_session.query(User).filter(User.email == 'similar_tester@example.com').delete()
        db_session.commit()
        db_session.remove()

    def test_01_movie_exists_returns_similar_movies(self):
        """TEST 1: Select a movie that exists in the dataset. Similar movies are returned."""
        # 19995 is Avatar in the benchmark dataset
        res = self.client.post('/api/movies/19995/similar')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['source'], 'machine_learning')
        self.assertGreater(len(data['recommendations']), 0)
        self.assertEqual(data['selected_movie']['title'], 'Avatar')

    def test_02_shawshank_redemption_recs_and_exclusion(self):
        """TEST 2: Select The Shawshank Redemption. Relevant candidates returned, query movie excluded."""
        res = self.client.post('/api/movies/278/similar', json={'title': 'The Shawshank Redemption'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['selected_movie']['title'], 'The Shawshank Redemption')
        
        recs = data['recommendations']
        self.assertGreater(len(recs), 0)
        rec_titles = [m['title'] for m in recs]
        self.assertNotIn('The Shawshank Redemption', rec_titles)

    def test_03_godfather_similar_movies(self):
        """TEST 3: Select The Godfather. Similar movies are returned."""
        res = self.client.post('/api/movies/238/similar', json={'title': 'The Godfather'})
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertEqual(data['selected_movie']['title'], 'The Godfather')
        recs = data['recommendations']
        self.assertGreater(len(recs), 0)
        rec_titles = [m['title'] for m in recs]
        self.assertNotIn('The Godfather', rec_titles)
        # Should include thematic crime/drama companion like The Godfather: Part II
        self.assertTrue(any('Godfather' in t for t in rec_titles))

    def test_04_unknown_movie_id_proper_error(self):
        """TEST 4: Select an unknown movie ID. Expected: Proper error response, not a server crash."""
        res = self.client.post('/api/movies/999999999/similar')
        # Expect either 404 with success=False, or a graceful error response, never status 500
        self.assertIn(res.status_code, [404, 200])
        data = res.get_json()
        self.assertFalse(data.get('success', False))
        self.assertIn('error', data)

    def test_05_selected_movie_never_in_own_recommendations(self):
        """TEST 5: Check that the selected movie is never included in its own recommendations."""
        test_movies = ['The Dark Knight', 'Inception', 'Interstellar', 'Titanic']
        for title in test_movies:
            res = self.recommender.recommend(title, top_n=10)
            self.assertTrue(res['success'])
            rec_titles = [m['title'] for m in res['recommendations']]
            rec_ids = [m['id'] for m in res['recommendations']]
            self.assertNotIn(title, rec_titles, f"Movie '{title}' was returned in its own recommendations!")
            self.assertNotIn(res['query_movie']['id'], rec_ids)

    def test_06_no_duplicate_movies_in_recommendations(self):
        """TEST 6: Check that no duplicate movies appear."""
        res = self.recommender.recommend('The Avengers', top_n=10)
        self.assertTrue(res['success'])
        rec_ids = [m['id'] for m in res['recommendations']]
        self.assertEqual(len(rec_ids), len(set(rec_ids)), "Duplicate movie IDs found in recommendations!")

    def test_07_similarity_scores_real_and_sorted_descending(self):
        """TEST 7: Check that similarity scores are real numerical values and are sorted from highest to lowest."""
        res = self.recommender.recommend('Gladiator', top_n=10)
        self.assertTrue(res['success'])
        recs = res['recommendations']
        self.assertGreater(len(recs), 0)

        scores = [m['similarity_score'] for m in recs]
        for score in scores:
            self.assertIsInstance(score, (float, int))
            self.assertGreater(score, 0.0)
            self.assertLessEqual(score, 100.0)

        # Check descending order
        sorted_scores = sorted(scores, reverse=True)
        self.assertEqual(scores, sorted_scores, "Recommendations are not sorted in descending similarity order!")

    def test_08_recommendations_count_not_exceed_ten(self):
        """TEST 8: Check that the number of recommendations does not exceed 10."""
        res = self.recommender.recommend('Avatar', top_n=10)
        self.assertTrue(res['success'])
        self.assertLessEqual(len(res['recommendations']), 10)

    def test_09_api_returns_valid_json_schema(self):
        """TEST 9: Check that the API returns valid JSON with all required keys."""
        res = self.client.post('/api/movies/155/similar')
        self.assertEqual(res.status_code, 200)
        self.assertTrue(res.is_json)
        data = res.get_json()
        self.assertIn('success', data)
        self.assertIn('source', data)
        self.assertIn('selected_movie', data)
        self.assertIn('recommendations', data)
        self.assertIn('count', data)

        selected = data['selected_movie']
        self.assertIn('id', selected)
        self.assertIn('title', selected)

        first_rec = data['recommendations'][0]
        self.assertIn('id', first_rec)
        self.assertIn('title', first_rec)
        self.assertIn('similarity_score', first_rec)

    def test_10_frontend_renders_recommendations(self):
        """TEST 10: Check that the frontend successfully renders recommendations page without error."""
        res = self.client.get('/recommend?movie=Inception')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Inception', res.data)
        self.assertIn(b'Machine Learning Recommendations', res.data)
        self.assertIn(b'Thematic Cluster', res.data)
        self.assertIn(b'btn-movie-similar', res.data)

    def test_11_system_handles_missing_poster_gracefully(self):
        """TEST 11: Check that the system behaves correctly when a poster is missing."""
        movie_dict = {
            'id': 1234567,
            'title': 'Test Film Without Poster',
            'poster_path': None
        }
        from services.tmdb_service import tmdb_service
        enriched = tmdb_service.enrich_movie(movie_dict)
        self.assertIsNone(enriched.get('poster_url'))
        self.assertEqual(enriched['title'], 'Test Film Without Poster')

    def test_12_model_consistency_and_integrity(self):
        """TEST 12: Check that model files are loaded properly and dimensions match."""
        self.assertTrue(self.recommender.is_loaded)
        self.assertIsNotNone(self.recommender.tfidf)
        self.assertIsNotNone(self.recommender.kmeans)
        self.assertIsNotNone(self.recommender.tfidf_matrix)
        self.assertIsNotNone(self.recommender.df)

        # Dimensionality check: Matrix rows must match dataframe length
        matrix_rows = self.recommender.tfidf_matrix.shape[0]
        df_rows = len(self.recommender.df)
        self.assertEqual(matrix_rows, df_rows, f"Matrix rows ({matrix_rows}) must equal df rows ({df_rows})!")

        # Contiguous index check
        self.assertEqual(list(self.recommender.df.index), list(range(df_rows)))

if __name__ == '__main__':
    unittest.main()

