import os
import sys
import unittest

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import app
from database.models import db_session, User, Watchlist, init_db
from ml.recommendation import MovieRecommender

class TestRecommendations(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        cls.recommender = MovieRecommender.get_instance()

    def setUp(self):
        app.config['TESTING'] = True
        self.client = app.test_client()

        # Create a test authenticated user
        db_session.query(Watchlist).delete()
        db_session.query(User).filter(User.email == 'rec_test@example.com').delete()
        db_session.commit()

        self.user = User(full_name="Rec Tester", email="rec_test@example.com")
        self.user.set_password("Secret123")
        db_session.add(self.user)
        db_session.commit()
        self.user_id = self.user.id

        # Log in test client
        with self.client.session_transaction() as sess:
            sess['user_id'] = self.user_id
            sess['user_name'] = "Rec Tester"
            sess['user_email'] = "rec_test@example.com"

    def tearDown(self):
        db_session.query(Watchlist).delete()
        db_session.query(User).filter(User.email == 'rec_test@example.com').delete()
        db_session.commit()
        db_session.remove()

    def test_search_autocomplete_api(self):
        res = self.client.get('/api/search?q=dark')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIsInstance(data, list)
        self.assertGreater(len(data), 0)
        titles = [m['title'].lower() for m in data]
        self.assertTrue(any('dark' in t for t in titles))

    def test_recommendation_pipeline_logic(self):
        # Recommend for 'The Dark Knight'
        result = self.recommender.recommend('The Dark Knight', top_n=10)
        self.assertTrue(result['success'])
        self.assertEqual(result['query_movie']['title'], 'The Dark Knight')
        
        recs = result['recommendations']
        self.assertEqual(len(recs), 10)

        # Requirement: Selected movie MUST be excluded from recommendation candidates
        rec_titles = [m['title'] for m in recs]
        self.assertNotIn('The Dark Knight', rec_titles)

        # Requirement: Similarity score and explanation must be present
        for rec in recs:
            self.assertIn('similarity_score', rec)
            self.assertIn('similarity_label', rec)
            self.assertIn('explanation', rec)
            self.assertGreater(rec['similarity_score'], 0)

    def test_recommendation_web_route(self):
        res = self.client.get('/recommend?movie=Avatar')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Avatar', res.data)
        self.assertIn(b'Machine Learning Recommendations', res.data)

    def test_watchlist_add_and_remove_api(self):
        # 1. Add movie
        add_res = self.client.post('/watchlist/add', json={'movie_id': 19995})
        self.assertEqual(add_res.status_code, 200)
        data = add_res.get_json()
        self.assertTrue(data['success'])

        # 2. Check duplicate addition handling
        dup_res = self.client.post('/watchlist/add', json={'movie_id': 19995})
        dup_data = dup_res.get_json()
        self.assertFalse(dup_data['success'])

        # 3. Check watchlist page
        w_page = self.client.get('/watchlist')
        self.assertEqual(w_page.status_code, 200)
        self.assertIn(b'Avatar', w_page.data)

        # 4. Remove movie
        del_res = self.client.delete('/watchlist/remove/19995')
        self.assertEqual(del_res.status_code, 200)
        del_data = del_res.get_json()
        self.assertTrue(del_data['success'])

if __name__ == '__main__':
    unittest.main()
