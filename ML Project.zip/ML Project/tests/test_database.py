import os
import sys
import unittest

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from database.models import db_session, User, Watchlist, RecommendationHistory, init_db

class TestDatabaseModels(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def setUp(self):
        # Clean any test users
        db_session.query(Watchlist).delete()
        db_session.query(RecommendationHistory).delete()
        db_session.query(User).filter(User.email.like('%test%@example.com')).delete()
        db_session.commit()

    def tearDown(self):
        db_session.rollback()

    def test_user_password_hashing(self):
        user = User(full_name="Test Student", email="test_student@example.com")
        user.set_password("Secret123")
        db_session.add(user)
        db_session.commit()

        # Verify password is not plain text
        self.assertNotEqual(user.password_hash, "Secret123")
        # Verify correct password validation
        self.assertTrue(user.check_password("Secret123"))
        # Verify incorrect password validation
        self.assertFalse(user.check_password("WrongPassword"))

    def test_duplicate_user_email_prevention(self):
        user1 = User(full_name="User One", email="test_dup@example.com")
        user1.set_password("Pass123")
        db_session.add(user1)
        db_session.commit()

        user2 = User(full_name="User Two", email="test_dup@example.com")
        user2.set_password("Pass456")
        db_session.add(user2)
        with self.assertRaises(Exception):
            db_session.commit()
        db_session.rollback()

    def test_watchlist_operations(self):
        user = User(full_name="Watchlist User", email="test_watch@example.com")
        user.set_password("Pass123")
        db_session.add(user)
        db_session.commit()

        # Add movie 19995 (Avatar)
        item = Watchlist(user_id=user.id, movie_id=19995, movie_title="Avatar", release_year=2009)
        db_session.add(item)
        db_session.commit()

        retrieved = db_session.query(Watchlist).filter_by(user_id=user.id, movie_id=19995).first()
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.movie_title, "Avatar")

        # Duplicate addition should trigger IntegrityError
        dup = Watchlist(user_id=user.id, movie_id=19995, movie_title="Avatar")
        db_session.add(dup)
        with self.assertRaises(Exception):
            db_session.commit()
        db_session.rollback()

    def test_recommendation_history_serialization(self):
        user = User(full_name="History User", email="test_hist@example.com")
        user.set_password("Pass123")
        db_session.add(user)
        db_session.commit()

        sample_recs = [
            {'id': 100, 'title': 'Movie A', 'similarity_label': '88.5% Similarity'},
            {'id': 200, 'title': 'Movie B', 'similarity_label': '82.1% Similarity'}
        ]

        hist = RecommendationHistory(
            user_id=user.id,
            selected_movie_id=999,
            selected_movie_title="Selected Movie",
            cluster_id=2
        )
        hist.set_recommendations(sample_recs)
        db_session.add(hist)
        db_session.commit()

        saved = db_session.query(RecommendationHistory).filter_by(user_id=user.id).first()
        self.assertIsNotNone(saved)
        loaded_recs = saved.get_recommendations()
        self.assertEqual(len(loaded_recs), 2)
        self.assertEqual(loaded_recs[0]['title'], 'Movie A')

if __name__ == '__main__':
    unittest.main()

