import os
import sys
import unittest

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from app import app
from database.models import db_session, User, init_db

class TestAuth(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        init_db()

        # Clean existing test users
        db_session.query(User).filter(User.email.like('%auth_test%@example.com')).delete()
        db_session.commit()

    def tearDown(self):
        db_session.query(User).filter(User.email.like('%auth_test%@example.com')).delete()
        db_session.commit()
        db_session.remove()

    def test_protected_routes_redirect_unauthenticated(self):
        # Accessing dashboard without login should redirect to /login
        res = self.client.get('/dashboard', follow_redirects=False)
        self.assertEqual(res.status_code, 302)
        self.assertIn('/login', res.headers['Location'])

    def test_user_registration_and_login_flow(self):
        # 1. Register new user
        reg_res = self.client.post('/register', data={
            'full_name': 'Auth Test User',
            'email': 'auth_test1@example.com',
            'password': 'Password123',
            'confirm_password': 'Password123'
        }, follow_redirects=True)
        self.assertEqual(reg_res.status_code, 200)
        self.assertIn(b'Registration successful', reg_res.data)

        # 2. Prevent duplicate registration
        dup_res = self.client.post('/register', data={
            'full_name': 'Duplicate User',
            'email': 'auth_test1@example.com',
            'password': 'Password123',
            'confirm_password': 'Password123'
        }, follow_redirects=True)
        self.assertIn(b'already exists', dup_res.data)

        # 3. Test invalid login password
        bad_login = self.client.post('/login', data={
            'email': 'auth_test1@example.com',
            'password': 'WrongPassword'
        }, follow_redirects=True)
        self.assertIn(b'Invalid email or password', bad_login.data)

        # 4. Test valid login
        good_login = self.client.post('/login', data={
            'email': 'auth_test1@example.com',
            'password': 'Password123'
        }, follow_redirects=True)
        self.assertEqual(good_login.status_code, 200)
        self.assertIn(b'Welcome back', good_login.data)

        # 5. Verify protected dashboard now accessible
        dash_res = self.client.get('/dashboard')
        self.assertEqual(dash_res.status_code, 200)
        self.assertIn(b'Auth Test User', dash_res.data)

        # 6. Test Profile page access & name update
        prof_res = self.client.get('/profile')
        self.assertEqual(prof_res.status_code, 200)
        self.assertIn(b'Account Profile', prof_res.data)

        update_prof = self.client.post('/profile', data={
            'action': 'update_profile',
            'full_name': 'Updated Student Name'
        }, follow_redirects=True)
        self.assertEqual(update_prof.status_code, 200)
        self.assertIn(b'Updated Student Name', update_prof.data)

        # 7. Test Password change
        pwd_change = self.client.post('/profile', data={
            'action': 'change_password',
            'current_password': 'Password123',
            'new_password': 'NewPassword456',
            'confirm_new_password': 'NewPassword456'
        }, follow_redirects=True)
        self.assertEqual(pwd_change.status_code, 200)
        self.assertIn(b'Password changed successfully', pwd_change.data)

        # 8. Test recommendation history page access
        hist_res = self.client.get('/history')
        self.assertEqual(hist_res.status_code, 200)
        self.assertIn(b'Recommendation History', hist_res.data)

        # 9. Test logout
        logout_res = self.client.get('/logout', follow_redirects=True)
        self.assertEqual(logout_res.status_code, 200)
        self.assertIn(b'logged out', logout_res.data)

if __name__ == '__main__':
    unittest.main()
